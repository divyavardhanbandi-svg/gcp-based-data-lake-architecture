"""
Data Quality Checks
--------------------
Runs schema conformance, null-rate, and range/enum validation against a
BigQuery table before it is promoted from staging to curated. Exits with
a non-zero status code if any check fails, so it can gate an Airflow task.

Usage:
    python data_quality_checks.py --project my-project \\
        --dataset staging_dataset --table events
"""

import argparse
import sys
from dataclasses import dataclass

from google.cloud import bigquery

REQUIRED_COLUMNS = ["event_id", "event_type", "source_system", "event_timestamp", "ingestion_date"]
MAX_NULL_RATE = 0.01          # fail if any required column exceeds 1% nulls
ALLOWED_EVENT_TYPES = None     # e.g. {"click", "purchase", "signup"} or None to skip enum check


@dataclass
class CheckResult:
    name: str
    passed: bool
    detail: str


def check_schema(client: bigquery.Client, table_ref: str) -> CheckResult:
    table = client.get_table(table_ref)
    actual_columns = {field.name for field in table.schema}
    missing = [c for c in REQUIRED_COLUMNS if c not in actual_columns]
    if missing:
        return CheckResult("schema_conformance", False, f"missing columns: {missing}")
    return CheckResult("schema_conformance", True, "all required columns present")


def check_null_rates(client: bigquery.Client, table_ref: str) -> CheckResult:
    null_checks = ", ".join(
        f"SAFE_DIVIDE(COUNTIF({col} IS NULL), COUNT(*)) AS {col}_null_rate"
        for col in REQUIRED_COLUMNS
    )
    query = f"SELECT {null_checks} FROM `{table_ref}`"
    row = list(client.query(query).result())[0]

    violations = {
        col: row[f"{col}_null_rate"]
        for col in REQUIRED_COLUMNS
        if (row[f"{col}_null_rate"] or 0) > MAX_NULL_RATE
    }

    if violations:
        return CheckResult("null_rate", False, f"columns exceeding {MAX_NULL_RATE:.0%} null rate: {violations}")
    return CheckResult("null_rate", True, f"all columns within {MAX_NULL_RATE:.0%} null threshold")


def check_duplicate_keys(client: bigquery.Client, table_ref: str) -> CheckResult:
    query = f"""
        SELECT event_id, COUNT(*) AS cnt
        FROM `{table_ref}`
        GROUP BY event_id
        HAVING cnt > 1
        LIMIT 10
    """
    duplicates = list(client.query(query).result())
    if duplicates:
        sample = [dict(row) for row in duplicates]
        return CheckResult("duplicate_keys", False, f"duplicate event_id values found: {sample}")
    return CheckResult("duplicate_keys", True, "no duplicate event_id values")


def check_enum_values(client: bigquery.Client, table_ref: str) -> CheckResult:
    if not ALLOWED_EVENT_TYPES:
        return CheckResult("enum_values", True, "skipped (no allow-list configured)")

    query = f"SELECT DISTINCT event_type FROM `{table_ref}`"
    found = {row["event_type"] for row in client.query(query).result()}
    unexpected = found - ALLOWED_EVENT_TYPES
    if unexpected:
        return CheckResult("enum_values", False, f"unexpected event_type values: {unexpected}")
    return CheckResult("enum_values", True, "all event_type values within allow-list")


def run_checks(project: str, dataset: str, table: str) -> list[CheckResult]:
    client = bigquery.Client(project=project)
    table_ref = f"{project}.{dataset}.{table}"

    return [
        check_schema(client, table_ref),
        check_null_rates(client, table_ref),
        check_duplicate_keys(client, table_ref),
        check_enum_values(client, table_ref),
    ]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--project", required=True)
    parser.add_argument("--dataset", required=True)
    parser.add_argument("--table", required=True)
    args = parser.parse_args()

    results = run_checks(args.project, args.dataset, args.table)

    print(f"\nData Quality Report: {args.project}.{args.dataset}.{args.table}")
    print("-" * 70)
    all_passed = True
    for result in results:
        status = "PASS" if result.passed else "FAIL"
        print(f"[{status}] {result.name}: {result.detail}")
        all_passed = all_passed and result.passed

    print("-" * 70)
    if not all_passed:
        print("Result: FAILED — one or more data quality checks did not pass.")
        sys.exit(1)

    print("Result: PASSED — all data quality checks succeeded.")
    sys.exit(0)


if __name__ == "__main__":
    main()
