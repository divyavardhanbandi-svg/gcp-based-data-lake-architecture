variable "project_id"  { type = string }
variable "region"      { type = string }
variable "environment" { type = string }

resource "google_bigquery_dataset" "staging" {
  dataset_id  = "staging_dataset"
  project     = var.project_id
  location    = var.region
  description = "Schema-validated, deduplicated data prior to curation"

  labels = { environment = var.environment, zone = "staging" }
}

resource "google_bigquery_dataset" "curated" {
  dataset_id  = "curated_dataset"
  project     = var.project_id
  location    = var.region
  description = "Business-ready curated tables for analytics and BI"

  labels = { environment = var.environment, zone = "curated" }
}

resource "google_bigquery_dataset" "marts" {
  dataset_id  = "marts_dataset"
  project     = var.project_id
  location    = var.region
  description = "Aggregated, domain-specific data marts"

  labels = { environment = var.environment, zone = "marts" }
}

resource "google_bigquery_dataset" "quarantine" {
  dataset_id  = "quarantine_dataset"
  project     = var.project_id
  location    = var.region
  description = "Records that failed data quality validation"

  labels = { environment = var.environment, zone = "quarantine" }
}

# Example partitioned + clustered staging table (extend per source system)
resource "google_bigquery_table" "events_staging" {
  dataset_id = google_bigquery_dataset.staging.dataset_id
  table_id   = "events"
  project    = var.project_id

  time_partitioning {
    type  = "DAY"
    field = "ingestion_date"
  }

  clustering = ["event_type", "source_system"]

  schema = jsonencode([
    { name = "event_id",       type = "STRING",    mode = "REQUIRED" },
    { name = "event_type",     type = "STRING",    mode = "REQUIRED" },
    { name = "source_system",  type = "STRING",    mode = "REQUIRED" },
    { name = "payload",        type = "JSON",      mode = "NULLABLE" },
    { name = "event_timestamp",type = "TIMESTAMP", mode = "REQUIRED" },
    { name = "ingestion_date",type = "DATE",       mode = "REQUIRED" }
  ])

  deletion_protection = false
}

output "staging_dataset_id"    { value = google_bigquery_dataset.staging.dataset_id }
output "curated_dataset_id"    { value = google_bigquery_dataset.curated.dataset_id }
output "marts_dataset_id"      { value = google_bigquery_dataset.marts.dataset_id }
output "quarantine_dataset_id" { value = google_bigquery_dataset.quarantine.dataset_id }
