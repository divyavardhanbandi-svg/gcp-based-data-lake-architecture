variable "project_id"  { type = string }
variable "environment" { type = string }

resource "google_pubsub_topic" "ingest" {
  name    = "${var.environment}-ingest-topic"
  project = var.project_id
}

resource "google_pubsub_topic" "dead_letter" {
  name    = "${var.environment}-ingest-dead-letter"
  project = var.project_id
}

resource "google_pubsub_subscription" "ingest_sub" {
  name    = "${var.environment}-ingest-subscription"
  topic   = google_pubsub_topic.ingest.name
  project = var.project_id

  ack_deadline_seconds = 60

  dead_letter_policy {
    dead_letter_topic     = google_pubsub_topic.dead_letter.id
    max_delivery_attempts = 5
  }

  retry_policy {
    minimum_backoff = "10s"
    maximum_backoff = "300s"
  }
}

output "topic_name"        { value = google_pubsub_topic.ingest.name }
output "subscription_name" { value = google_pubsub_subscription.ingest_sub.name }
