variable "project_id"   { type = string }
variable "region"       { type = string }
variable "environment"  { type = string }
variable "force_destroy" { type = bool }

resource "google_storage_bucket" "raw" {
  name                        = "${var.project_id}-${var.environment}-raw"
  location                    = var.region
  force_destroy               = var.force_destroy
  uniform_bucket_level_access = true

  versioning { enabled = true }

  lifecycle_rule {
    condition { age = 30 }
    action {
      type          = "SetStorageClass"
      storage_class = "NEARLINE"
    }
  }

  lifecycle_rule {
    condition { age = 90 }
    action {
      type          = "SetStorageClass"
      storage_class = "COLDLINE"
    }
  }
}

resource "google_storage_bucket" "staging" {
  name                        = "${var.project_id}-${var.environment}-staging"
  location                    = var.region
  force_destroy               = var.force_destroy
  uniform_bucket_level_access = true

  lifecycle_rule {
    condition { age = 14 }
    action {
      type = "Delete"
    }
  }
}

resource "google_storage_bucket" "curated" {
  name                        = "${var.project_id}-${var.environment}-curated"
  location                    = var.region
  force_destroy               = var.force_destroy
  uniform_bucket_level_access = true

  versioning { enabled = true }
}

resource "google_storage_bucket" "quarantine" {
  name                        = "${var.project_id}-${var.environment}-quarantine"
  location                    = var.region
  force_destroy               = var.force_destroy
  uniform_bucket_level_access = true
}

output "raw_bucket_name"        { value = google_storage_bucket.raw.name }
output "staging_bucket_name"    { value = google_storage_bucket.staging.name }
output "curated_bucket_name"    { value = google_storage_bucket.curated.name }
output "quarantine_bucket_name" { value = google_storage_bucket.quarantine.name }
