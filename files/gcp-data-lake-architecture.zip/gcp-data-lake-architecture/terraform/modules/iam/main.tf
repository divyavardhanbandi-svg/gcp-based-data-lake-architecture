variable "project_id"       { type = string }
variable "raw_bucket"       { type = string }
variable "staging_bucket"   { type = string }
variable "curated_bucket"   { type = string }
variable "bigquery_dataset" { type = string }

# --- Raw ingest service account: write-only to raw bucket ------------------
resource "google_service_account" "raw_ingest" {
  account_id   = "raw-ingest-sa"
  display_name = "Raw Zone Ingestion Service Account"
  project      = var.project_id
}

resource "google_storage_bucket_iam_member" "raw_ingest_writer" {
  bucket = var.raw_bucket
  role   = "roles/storage.objectCreator"
  member = "serviceAccount:${google_service_account.raw_ingest.email}"
}

# --- Pipeline service account: read raw / write staging & curated ----------
resource "google_service_account" "pipeline" {
  account_id   = "pipeline-sa"
  display_name = "Data Lake Pipeline Service Account"
  project      = var.project_id
}

resource "google_storage_bucket_iam_member" "pipeline_raw_reader" {
  bucket = var.raw_bucket
  role   = "roles/storage.objectViewer"
  member = "serviceAccount:${google_service_account.pipeline.email}"
}

resource "google_storage_bucket_iam_member" "pipeline_staging_writer" {
  bucket = var.staging_bucket
  role   = "roles/storage.objectAdmin"
  member = "serviceAccount:${google_service_account.pipeline.email}"
}

resource "google_storage_bucket_iam_member" "pipeline_curated_writer" {
  bucket = var.curated_bucket
  role   = "roles/storage.objectAdmin"
  member = "serviceAccount:${google_service_account.pipeline.email}"
}

resource "google_project_iam_member" "pipeline_bq_job_user" {
  project = var.project_id
  role    = "roles/bigquery.jobUser"
  member  = "serviceAccount:${google_service_account.pipeline.email}"
}

resource "google_project_iam_member" "pipeline_dataflow_worker" {
  project = var.project_id
  role    = "roles/dataflow.worker"
  member  = "serviceAccount:${google_service_account.pipeline.email}"
}

# --- Analytics service account: read-only on curated data ------------------
resource "google_service_account" "analytics" {
  account_id   = "analytics-sa"
  display_name = "BI / Analytics Read-Only Service Account"
  project      = var.project_id
}

resource "google_storage_bucket_iam_member" "analytics_curated_reader" {
  bucket = var.curated_bucket
  role   = "roles/storage.objectViewer"
  member = "serviceAccount:${google_service_account.analytics.email}"
}

resource "google_bigquery_dataset_iam_member" "analytics_bq_reader" {
  project    = var.project_id
  dataset_id = var.bigquery_dataset
  role       = "roles/bigquery.dataViewer"
  member     = "serviceAccount:${google_service_account.analytics.email}"
}

output "raw_ingest_service_account_email" { value = google_service_account.raw_ingest.email }
output "pipeline_service_account_email"   { value = google_service_account.pipeline.email }
output "analytics_service_account_email"  { value = google_service_account.analytics.email }
