terraform {
  required_version = ">= 1.5.0"
  required_providers {
    google = {
      source  = "hashicorp/google"
      version = "~> 5.0"
    }
  }
}

provider "google" {
  project = var.project_id
  region  = var.region
}

# ---------------------------------------------------------------------------
# Multi-zone Cloud Storage lake: raw / staging / curated
# ---------------------------------------------------------------------------
module "storage" {
  source       = "./modules/storage"
  project_id   = var.project_id
  region       = var.region
  environment  = var.environment
  force_destroy = var.force_destroy
}

# ---------------------------------------------------------------------------
# BigQuery datasets & partitioned tables for staging/curated/marts
# ---------------------------------------------------------------------------
module "bigquery" {
  source      = "./modules/bigquery"
  project_id  = var.project_id
  region      = var.region
  environment = var.environment
}

# ---------------------------------------------------------------------------
# Pub/Sub topic + subscription for streaming ingestion
# ---------------------------------------------------------------------------
module "pubsub" {
  source      = "./modules/pubsub"
  project_id  = var.project_id
  environment = var.environment
}

# ---------------------------------------------------------------------------
# Service accounts & least-privilege IAM bindings per zone
# ---------------------------------------------------------------------------
module "iam" {
  source            = "./modules/iam"
  project_id        = var.project_id
  raw_bucket        = module.storage.raw_bucket_name
  staging_bucket    = module.storage.staging_bucket_name
  curated_bucket    = module.storage.curated_bucket_name
  bigquery_dataset  = module.bigquery.staging_dataset_id
}
