output "raw_bucket" {
  value = module.storage.raw_bucket_name
}

output "staging_bucket" {
  value = module.storage.staging_bucket_name
}

output "curated_bucket" {
  value = module.storage.curated_bucket_name
}

output "bigquery_staging_dataset" {
  value = module.bigquery.staging_dataset_id
}

output "bigquery_curated_dataset" {
  value = module.bigquery.curated_dataset_id
}

output "pubsub_topic" {
  value = module.pubsub.topic_name
}

output "pipeline_service_account" {
  value = module.iam.pipeline_service_account_email
}
