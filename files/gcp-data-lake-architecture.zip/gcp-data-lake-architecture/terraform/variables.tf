variable "project_id" {
  description = "GCP project ID to deploy the data lake into"
  type        = string
}

variable "region" {
  description = "Primary GCP region for resources"
  type        = string
  default     = "us-central1"
}

variable "environment" {
  description = "Deployment environment name (dev/staging/prod)"
  type        = string
  default     = "dev"
}

variable "force_destroy" {
  description = "Allow Terraform to delete non-empty buckets (use false in prod)"
  type        = bool
  default     = false
}
