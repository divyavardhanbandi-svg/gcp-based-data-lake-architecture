"""
Cloud Composer DAG: data_lake_etl
----------------------------------
Orchestrates the daily data lake pipeline:

  1. Sensor waits for new files in the raw GCS zone
  2. Launches the Dataflow batch pipeline (raw -> staging BigQuery)
  3. Runs data quality checks against the staging table
  4. Promotes validated data from staging -> curated (BigQuery SQL)
  5. Refreshes the downstream analytics mart

Schedule: daily at 02:00 UTC.
"""

from datetime import datetime, timedelta

from airflow import DAG
from airflow.providers.google.cloud.sensors.gcs import GCSObjectsWithPrefixExistenceSensor
from airflow.providers.google.cloud.operators.dataflow import DataflowStartFlexTemplateOperator
from airflow.providers.google.cloud.operators.bigquery import BigQueryInsertJobOperator
from airflow.operators.python import PythonOperator

PROJECT_ID = "{{ var.value.gcp_project_id }}"
REGION = "us-central1"
ENVIRONMENT = "{{ var.value.environment }}"

RAW_BUCKET = f"{PROJECT_ID}-{ENVIRONMENT}-raw"
STAGING_DATASET = "staging_dataset"
CURATED_DATASET = "curated_dataset"
MARTS_DATASET = "marts_dataset"

default_args = {
    "owner": "data-platform",
    "retries": 3,
    "retry_delay": timedelta(minutes=5),
    "email_on_failure": True,
}

with DAG(
    dag_id="data_lake_etl",
    description="Raw -> Staging -> Curated -> Marts data lake pipeline",
    default_args=default_args,
    schedule_interval="0 2 * * *",
    start_date=datetime(2026, 1, 1),
    catchup=False,
    max_active_runs=1,
    tags=["data-lake", "gcp", "etl"],
) as dag:

    wait_for_raw_files = GCSObjectsWithPrefixExistenceSensor(
        task_id="wait_for_raw_files",
        bucket=RAW_BUCKET,
        prefix="incoming/",
        poke_interval=300,
        timeout=60 * 60 * 3,
        mode="reschedule",
    )

    run_batch_pipeline = DataflowStartFlexTemplateOperator(
        task_id="run_batch_pipeline",
        project_id=PROJECT_ID,
        location=REGION,
        body={
            "launchParameter": {
                "jobName": "data-lake-batch-{{ ds_nodash }}",
                "containerSpecGcsPath": f"gs://{PROJECT_ID}-{ENVIRONMENT}-staging/templates/batch_pipeline.json",
                "parameters": {
                    "input": f"gs://{RAW_BUCKET}/incoming/*.json",
                    "output_dataset": STAGING_DATASET,
                    "quarantine_output": f"gs://{PROJECT_ID}-{ENVIRONMENT}-quarantine/pipeline_rejects/{{{{ ds }}}}/",
                },
            }
        },
    )

    def _run_data_quality_checks(**context):
        """Invokes the standalone data quality script against the staging table."""
        import subprocess
        import sys

        result = subprocess.run(
            [sys.executable, "/home/airflow/gcs/dags/scripts/data_quality_checks.py",
             "--project", PROJECT_ID, "--dataset", STAGING_DATASET, "--table", "events"],
            capture_output=True, text=True,
        )
        if result.returncode != 0:
            raise RuntimeError(f"Data quality checks failed:\n{result.stdout}\n{result.stderr}")

    data_quality_checks = PythonOperator(
        task_id="data_quality_checks",
        python_callable=_run_data_quality_checks,
    )

    promote_to_curated = BigQueryInsertJobOperator(
        task_id="promote_to_curated",
        configuration={
            "query": {
                "query": f"""
                    CREATE TABLE IF NOT EXISTS `{PROJECT_ID}.{CURATED_DATASET}.events`
                    PARTITION BY ingestion_date
                    CLUSTER BY event_type, source_system AS
                    SELECT * FROM `{PROJECT_ID}.{STAGING_DATASET}.events`
                    WHERE ingestion_date = CURRENT_DATE()
                    AND event_id NOT IN (
                        SELECT event_id FROM `{PROJECT_ID}.{CURATED_DATASET}.events`
                    );
                """,
                "useLegacySql": False,
            }
        },
        location=REGION,
    )

    refresh_marts = BigQueryInsertJobOperator(
        task_id="refresh_marts",
        configuration={
            "query": {
                "query": f"""
                    CREATE OR REPLACE TABLE `{PROJECT_ID}.{MARTS_DATASET}.daily_event_summary` AS
                    SELECT
                        ingestion_date,
                        event_type,
                        source_system,
                        COUNT(*) AS event_count
                    FROM `{PROJECT_ID}.{CURATED_DATASET}.events`
                    GROUP BY ingestion_date, event_type, source_system;
                """,
                "useLegacySql": False,
            }
        },
        location=REGION,
    )

    wait_for_raw_files >> run_batch_pipeline >> data_quality_checks >> promote_to_curated >> refresh_marts
