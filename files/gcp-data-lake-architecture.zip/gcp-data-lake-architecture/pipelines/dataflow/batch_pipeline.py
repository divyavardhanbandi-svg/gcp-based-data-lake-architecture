"""
Batch Dataflow pipeline: Raw GCS -> Cleansed -> BigQuery staging.

Reads newline-delimited JSON objects landed in the raw GCS zone, applies
schema normalization and deduplication, writes rejects to a quarantine
GCS prefix, and loads valid rows into the BigQuery staging dataset.

Run locally (DirectRunner):
    python batch_pipeline.py \\
        --input data/sample_events.json \\
        --output_dataset staging_dataset \\
        --temp_location /tmp/beam_temp \\
        --runner DirectRunner

Run on Dataflow:
    python batch_pipeline.py \\
        --runner DataflowRunner \\
        --project <PROJECT_ID> \\
        --region us-central1 \\
        --input gs://<project>-raw/incoming/*.json \\
        --output_dataset staging_dataset \\
        --temp_location gs://<project>-staging/tmp \\
        --staging_location gs://<project>-staging/staging \\
        --autoscaling_algorithm THROUGHPUT_BASED \\
        --max_num_workers 10
"""

import argparse
import json
import logging
from datetime import datetime, timezone

import apache_beam as beam
from apache_beam.io.gcp.bigquery import WriteToBigQuery, BigQueryDisposition
from apache_beam.options.pipeline_options import PipelineOptions

REQUIRED_FIELDS = ["event_id", "event_type", "source_system", "event_timestamp"]

BQ_SCHEMA = {
    "fields": [
        {"name": "event_id", "type": "STRING", "mode": "REQUIRED"},
        {"name": "event_type", "type": "STRING", "mode": "REQUIRED"},
        {"name": "source_system", "type": "STRING", "mode": "REQUIRED"},
        {"name": "payload", "type": "JSON", "mode": "NULLABLE"},
        {"name": "event_timestamp", "type": "TIMESTAMP", "mode": "REQUIRED"},
        {"name": "ingestion_date", "type": "DATE", "mode": "REQUIRED"},
    ]
}


class ParseAndValidate(beam.DoFn):
    """Parses a JSON line and tags it as valid or invalid."""

    OUTPUT_VALID = "valid"
    OUTPUT_INVALID = "invalid"

    def process(self, element):
        try:
            record = json.loads(element)
        except json.JSONDecodeError:
            yield beam.pvalue.TaggedOutput(self.OUTPUT_INVALID, {"raw": element, "error": "invalid_json"})
            return

        missing = [f for f in REQUIRED_FIELDS if f not in record]
        if missing:
            record["_error"] = f"missing_fields:{missing}"
            yield beam.pvalue.TaggedOutput(self.OUTPUT_INVALID, record)
            return

        record["ingestion_date"] = datetime.now(timezone.utc).strftime("%Y-%m-%d")
        record.setdefault("payload", {})
        yield beam.pvalue.TaggedOutput(self.OUTPUT_VALID, record)


def dedup_key(record):
    return record["event_id"], record


def run(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True, help="GCS glob or local path to raw JSON lines")
    parser.add_argument("--output_dataset", required=True, help="Target BigQuery dataset")
    parser.add_argument("--output_table", default="events", help="Target BigQuery table")
    parser.add_argument("--quarantine_output", default=None, help="GCS prefix for rejected records")
    known_args, pipeline_args = parser.parse_known_args(argv)

    options = PipelineOptions(pipeline_args, save_main_session=True)

    with beam.Pipeline(options=options) as pipeline:
        parsed = (
            pipeline
            | "ReadRawEvents" >> beam.io.ReadFromText(known_args.input)
            | "ParseAndValidate" >> beam.ParDo(ParseAndValidate()).with_outputs(
                ParseAndValidate.OUTPUT_VALID, ParseAndValidate.OUTPUT_INVALID
            )
        )

        valid_records = (
            parsed[ParseAndValidate.OUTPUT_VALID]
            | "KeyByEventId" >> beam.Map(dedup_key)
            | "DedupById" >> beam.CombinePerKey(lambda records: next(iter(records)))
            | "DropKey" >> beam.Map(lambda kv: kv[1])
        )

        valid_records | "WriteToBigQuery" >> WriteToBigQuery(
            table=known_args.output_table,
            dataset=known_args.output_dataset,
            schema=BQ_SCHEMA,
            write_disposition=BigQueryDisposition.WRITE_APPEND,
            create_disposition=BigQueryDisposition.CREATE_IF_NEEDED,
        )

        if known_args.quarantine_output:
            (
                parsed[ParseAndValidate.OUTPUT_INVALID]
                | "FormatInvalid" >> beam.Map(json.dumps)
                | "WriteQuarantine" >> beam.io.WriteToText(
                    known_args.quarantine_output, file_name_suffix=".json"
                )
            )


if __name__ == "__main__":
    logging.getLogger().setLevel(logging.INFO)
    run()
