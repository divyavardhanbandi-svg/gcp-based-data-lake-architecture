"""
Cloud Function: validate_and_land
----------------------------------
Triggered by Pub/Sub messages on the streaming ingest topic. Performs
lightweight schema/shape validation, then lands the payload as a JSON
object in the raw GCS zone, partitioned by ingestion date. Invalid
messages are routed to the quarantine bucket instead of failing the
whole pipeline.
"""

import base64
import json
import logging
import os
import uuid
from datetime import datetime, timezone

from google.cloud import storage

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("validate_and_land")

RAW_BUCKET = os.environ.get("RAW_BUCKET", "REPLACE_WITH_RAW_BUCKET")
QUARANTINE_BUCKET = os.environ.get("QUARANTINE_BUCKET", "REPLACE_WITH_QUARANTINE_BUCKET")

REQUIRED_FIELDS = ["event_id", "event_type", "source_system", "event_timestamp"]

storage_client = storage.Client()


def _validate(payload: dict) -> tuple[bool, str | None]:
    """Basic structural validation. Extend with real schema checks as needed."""
    missing = [f for f in REQUIRED_FIELDS if f not in payload]
    if missing:
        return False, f"missing required fields: {missing}"

    if not isinstance(payload.get("event_id"), str):
        return False, "event_id must be a string"

    try:
        datetime.fromisoformat(payload["event_timestamp"].replace("Z", "+00:00"))
    except (ValueError, AttributeError):
        return False, "event_timestamp must be a valid ISO-8601 string"

    return True, None


def _write_object(bucket_name: str, prefix: str, payload: dict) -> str:
    bucket = storage_client.bucket(bucket_name)
    ingestion_date = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    object_name = f"{prefix}/{ingestion_date}/{uuid.uuid4()}.json"
    blob = bucket.blob(object_name)
    blob.upload_from_string(json.dumps(payload), content_type="application/json")
    return object_name


def validate_and_land(event, context):
    """Pub/Sub-triggered entry point.

    Args:
        event (dict): Pub/Sub message payload, base64-encoded in event['data'].
        context (google.cloud.functions.Context): Metadata for the event.
    """
    try:
        raw_data = base64.b64decode(event["data"]).decode("utf-8")
        payload = json.loads(raw_data)
    except (KeyError, ValueError) as exc:
        logger.error("Failed to decode message: %s", exc)
        _write_object(QUARANTINE_BUCKET, "malformed", {"error": str(exc)})
        return

    is_valid, reason = _validate(payload)

    if is_valid:
        object_name = _write_object(RAW_BUCKET, "incoming", payload)
        logger.info("Landed event %s -> %s", payload.get("event_id"), object_name)
    else:
        payload["_quarantine_reason"] = reason
        object_name = _write_object(QUARANTINE_BUCKET, "invalid", payload)
        logger.warning("Quarantined event: %s (%s)", reason, object_name)
